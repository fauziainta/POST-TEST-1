/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.klinikkecantikan;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Main {

    static Scanner objekScanner = new Scanner(System.in);
    static ArrayList<String> namaCustomer = new ArrayList<>();
    static ArrayList<String> layanan = new ArrayList<>();
    static ArrayList<String> tanggal = new ArrayList<>();
    static ArrayList<String> waktu = new ArrayList<>();
    static ArrayList<String> waktuTersedia = new ArrayList<>();
    static ArrayList<String> layananTersedia = new ArrayList<>();
    
    public static void main(String[] args) { 
        waktuTersedia.add("10:00");
        waktuTersedia.add("13:00");
        waktuTersedia.add("15:00");
        waktuTersedia.add("18:00");

        layananTersedia.add("Peeling Acne");
        layananTersedia.add("Laser Rejuvenation");
        layananTersedia.add("Skin Booster Salmon DNA");
        layananTersedia.add("Facial");
        layananTersedia.add("Microneedling");
    
    while (true) {
        System.out.println("\n<3 <3 RESERVASI KLINIK KECANTIKAN <3 <3");
        System.out.println("1. Tambah Reservasi");
        System.out.println("2. Lihat Reservasi");
        System.out.println("3. Ubah Reservasi");
        System.out.println("4. Hapus Reservasi");
        System.out.println("5. Keluar");
        System.out.print("Pilih menu: ");
        
        int pilih;
        try {
        pilih = Integer.parseInt(objekScanner.nextLine());
        } catch (NumberFormatException e) {
        System.out.println("Input harus berupa angka!");
        continue; 
}

    
                switch (pilih) {
                case 1:
                    tambahReservasi();
                    break;
                case 2:
                    lihatReservasi();
                    break;
                case 3:
                    ubahReservasi();
                    break;
                case 4:
                    hapusReservasi();
                    break;
                case 5:
                    System.out.println("Thanks for using this reservation program <3.");
                    return;
                default:
                    System.out.println("Menu tidak valid!");
            }
        }
    }
    
        public static void tambahReservasi() {
        System.out.print("Masukkan nama customer: ");
        String nama = objekScanner.nextLine();

        System.out.print("Masukkan tanggal (dd-mm-yyyy): ");
        String tgl = objekScanner.nextLine();

        System.out.println("Pilih waktu tersedia:");
        for (int i = 0; i < waktuTersedia.size(); i++) {
            System.out.println((i + 1) + ". " + waktuTersedia.get(i));
        }
        System.out.print("Pilih nomor waktu: ");
        int pilihWaktu = Integer.parseInt(objekScanner.nextLine());
        String wkt = waktuTersedia.get(pilihWaktu - 1);

        System.out.println("Pilih layanan tersedia:");
        for (int i = 0; i < layananTersedia.size(); i++) {
            System.out.println((i + 1) + ". " + layananTersedia.get(i));
        }
        System.out.print("Pilih nomor layanan: ");
        int pilihLayanan = Integer.parseInt(objekScanner.nextLine());
        String layan = layananTersedia.get(pilihLayanan - 1);

        namaCustomer.add(nama);
        tanggal.add(tgl);
        waktu.add(wkt);
        layanan.add(layan);

        System.out.println("Reservasi berhasil ditambahkan<3");
    }

    public static void lihatReservasi() {
        if (namaCustomer.isEmpty()) {
            System.out.println("Belum ada data reservasi, yuk create reservation! T___T.");
            return;
        }
        System.out.println("\n<3 <3 DAFTAR RESERVASI <3 <3");
        for (int i = 0; i < namaCustomer.size(); i++) {
            System.out.println((i + 1) + ". Nama: " + namaCustomer.get(i) +
                    ", Tanggal: " + tanggal.get(i) +
                    ", Waktu: " + waktu.get(i) +
                    ", Layanan: " + layanan.get(i));
        }
    }

    public static void ubahReservasi() {
        lihatReservasi();
        if (namaCustomer.isEmpty()) return;

        System.out.print("Pilih nomor reservasi yang ingin diubah: ");
        int index = Integer.parseInt(objekScanner.nextLine()) - 1;

        if (index < 0 || index >= namaCustomer.size()) {
            System.out.println("Nomor tidak valid!");
            return;
        }

        System.out.print("Masukkan tanggal baru (dd-mm-yyyy): ");
        String tgl = objekScanner.nextLine();

        System.out.println("Pilih waktu baru:");
        for (int i = 0; i < waktuTersedia.size(); i++) {
            System.out.println((i + 1) + ". " + waktuTersedia.get(i));
        }
        System.out.print("Pilih nomor waktu: ");
        int pilihWaktu = Integer.parseInt(objekScanner.nextLine());
        String wkt = waktuTersedia.get(pilihWaktu - 1);

        System.out.println("Pilih layanan baru:");
        for (int i = 0; i < layananTersedia.size(); i++) {
            System.out.println((i + 1) + ". " + layananTersedia.get(i));
        }
        System.out.print("Pilih nomor layanan: ");
        int pilihLayanan = Integer.parseInt(objekScanner.nextLine());
        String layan = layananTersedia.get(pilihLayanan - 1);

        tanggal.set(index, tgl);
        waktu.set(index, wkt);
        layanan.set(index, layan);

        System.out.println("Reservasi berhasil diubah!");
    }

    public static void hapusReservasi() {
        lihatReservasi();
        if (namaCustomer.isEmpty()) return;

        System.out.print("Pilih nomor reservasi yang ingin dihapus: ");
        int index = Integer.parseInt(objekScanner.nextLine()) - 1;

        if (index < 0 || index >= namaCustomer.size()) {
            System.out.println("Nomor tidak valid!");
            return;
        }

        namaCustomer.remove(index);
        tanggal.remove(index);
        waktu.remove(index);
        layanan.remove(index);

        System.out.println("Reservasi berhasil dihapus!");
    }
}
    

